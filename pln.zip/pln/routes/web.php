//route CRUD
Route::get('/tb_pelanggan','tb_pelangganController@index');
Route::get('/tb_golongan','tb_golonganController@index');
Route::get('/tb_users','tb_usersController@index');