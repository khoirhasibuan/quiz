'mysql' => array(
    'driver'    => 'mysql',
    'host'      => 'localhost',
    'database'  => 'pln', <------ change name for database
    'username'  => 'root',            <------ remember credentials
    'password'  => '',
    'charset'   => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix'    => '',
),